export type Category = "cm" | "media" | "ads" | "media-fee"

export interface CategoryConfig {
  id: Category
  label: string
  shortLabel: string
  color: string
  lightColor: string
  fgColor: string
  borderColor: string
  gradient: string
}

export const categories: CategoryConfig[] = [
  {
    id: "cm",
    label: "Contribution Margin",
    shortLabel: "CM",
    color: "bg-mint",
    lightColor: "bg-mint-light",
    fgColor: "text-mint-foreground",
    borderColor: "border-mint",
    gradient: "from-mint/60 to-mint/30",
  },
  {
    id: "media",
    label: "Media",
    shortLabel: "Media",
    color: "bg-blue",
    lightColor: "bg-blue-light",
    fgColor: "text-blue-foreground",
    borderColor: "border-blue",
    gradient: "from-blue/60 to-blue/30",
  },
  {
    id: "ads",
    label: "Ads",
    shortLabel: "Ads",
    color: "bg-rose",
    lightColor: "bg-rose-light",
    fgColor: "text-rose-foreground",
    borderColor: "border-rose",
    gradient: "from-rose/60 to-rose/30",
  },
  {
    id: "media-fee",
    label: "Media Fee",
    shortLabel: "Fee",
    color: "bg-amber",
    lightColor: "bg-amber-light",
    fgColor: "text-amber-foreground",
    borderColor: "border-amber",
    gradient: "from-amber/60 to-amber/30",
  },
]

// --- New metric-based data model ---

export interface MonthData {
  target: number
  dailyTarget: number
  achievement: number
  achievementRate: number
  dailyAchievement: number
  dailyAchievementRate: number
  momOrQoq: number // M/M for months, Q/Q for quarters
}

export interface QuarterData {
  label: string          // "Q1", "Q2"
  months: {
    label: string        // "Jan", "Feb", "Mar"
    data: MonthData
  }[]
  total: MonthData       // Quarter-level aggregates
}

export interface SectionData {
  category: Category
  quarters: QuarterData[]
}

export const quarterlyMetricLabels = [
  "Target",
  "Daily Target",
  "Achievement",
  "Achievement Rate",
  "Daily Achievement",
  "Daily Achievement Rate",
  "Daily Q/Q",
]

export const monthlyMetricLabels = [
  "Target",
  "Daily Target",
  "Achievement",
  "Achievement Rate",
  "Daily Achievement",
  "Daily Achievement Rate",
  "Daily M/M",
]

// Simple seeded PRNG to avoid hydration mismatch
function seededRandom(seed: number): () => number {
  let s = seed
  return () => {
    s = (s * 16807 + 0) % 2147483647
    return (s - 1) / 2147483646
  }
}

function generateMonthData(rand: () => number, base: number): MonthData {
  const target = Math.round(base * (0.9 + rand() * 0.2))
  const achievement = Math.round(target * (0.7 + rand() * 0.45))
  const rate = Math.round((achievement / target) * 1000) / 10
  const daysInMonth = 30
  const dailyTarget = Math.round(target / daysInMonth)
  const daysPassed = Math.round(15 + rand() * 15)
  const dailyAchievement = Math.round(achievement / daysPassed)
  const dailyRate = Math.round((dailyAchievement / dailyTarget) * 1000) / 10
  const momOrQoq = Math.round((-15 + rand() * 30) * 10) / 10

  return {
    target,
    dailyTarget,
    achievement,
    achievementRate: rate,
    dailyAchievement,
    dailyAchievementRate: dailyRate,
    momOrQoq,
  }
}

function generateQuarter(
  rand: () => number,
  label: string,
  monthLabels: string[],
  base: number
): QuarterData {
  const months = monthLabels.map((ml) => ({
    label: ml,
    data: generateMonthData(rand, base),
  }))

  const totalTarget = months.reduce((s, m) => s + m.data.target, 0)
  const totalAchievement = months.reduce((s, m) => s + m.data.achievement, 0)
  const totalDailyTarget = months.reduce((s, m) => s + m.data.dailyTarget, 0)
  const totalDailyAchievement = months.reduce((s, m) => s + m.data.dailyAchievement, 0)

  const total: MonthData = {
    target: totalTarget,
    dailyTarget: Math.round(totalDailyTarget / 3),
    achievement: totalAchievement,
    achievementRate: Math.round((totalAchievement / totalTarget) * 1000) / 10,
    dailyAchievement: Math.round(totalDailyAchievement / 3),
    dailyAchievementRate:
      Math.round(
        ((totalDailyAchievement / 3) / (totalDailyTarget / 3)) * 1000
      ) / 10,
    momOrQoq: Math.round((-10 + rand() * 20) * 10) / 10,
  }

  return { label, months, total }
}

const rand = seededRandom(42)

export const sections: SectionData[] = [
  {
    category: "cm",
    quarters: [
      generateQuarter(rand, "Q1", ["Jan", "Feb", "Mar"], 150000),
      generateQuarter(rand, "Q2", ["Apr", "May", "Jun"], 165000),
    ],
  },
  {
    category: "media",
    quarters: [
      generateQuarter(rand, "Q1", ["Jan", "Feb", "Mar"], 85000),
      generateQuarter(rand, "Q2", ["Apr", "May", "Jun"], 92000),
    ],
  },
  {
    category: "ads",
    quarters: [
      generateQuarter(rand, "Q1", ["Jan", "Feb", "Mar"], 62000),
      generateQuarter(rand, "Q2", ["Apr", "May", "Jun"], 68000),
    ],
  },
  {
    category: "media-fee",
    quarters: [
      generateQuarter(rand, "Q1", ["Jan", "Feb", "Mar"], 22000),
      generateQuarter(rand, "Q2", ["Apr", "May", "Jun"], 25000),
    ],
  },
]

export function getCategoryConfig(id: string): CategoryConfig {
  return categories.find((c) => c.id === id)!
}
