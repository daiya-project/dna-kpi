"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { DashboardHeader } from "@/components/dashboard-header"
import { ControlBar } from "@/components/control-bar"
import { BookmarkTabs } from "@/components/bookmark-tabs"
import { KPITable } from "@/components/kpi-table"
import {
  categories,
  sections,
  getCategoryConfig,
  type Category,
} from "@/lib/dashboard-data"

function formatNumber(num: number): string {
  if (num >= 1000) return num.toLocaleString("en-US")
  return num.toString()
}

export default function DashboardPage() {
  const [activeRegion, setActiveRegion] = useState("summary")
  const [activeFilter, setActiveFilter] = useState<string | null>(null)
  const [activeScrollCategory, setActiveScrollCategory] = useState<string | null>(null)
  const sectionRefs = useRef<Record<string, HTMLTableSectionElement | null>>({})

  const handleFilterChange = useCallback((value: string) => {
    if (value === activeFilter || value === "") {
      setActiveFilter(null)
    } else {
      setActiveFilter(value)
      const el = sectionRefs.current[value]
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "start" })
      }
    }
  }, [activeFilter])

  const handleBookmarkClick = useCallback((id: string) => {
    setActiveFilter(id)
    const el = sectionRefs.current[id]
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" })
    }
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visibleEntries = entries.filter((e) => e.isIntersecting)
        if (visibleEntries.length > 0) {
          const sorted = visibleEntries.sort(
            (a, b) => a.boundingClientRect.top - b.boundingClientRect.top
          )
          const topEntry = sorted[0]
          const sectionId = topEntry.target.id.replace("section-", "")
          setActiveScrollCategory(sectionId)
        }
      },
      {
        rootMargin: "-120px 0px -50% 0px",
        threshold: 0,
      }
    )

    const currentRefs = sectionRefs.current
    Object.values(currentRefs).forEach((el) => {
      if (el) observer.observe(el)
    })

    return () => {
      Object.values(currentRefs).forEach((el) => {
        if (el) observer.unobserve(el)
      })
    }
  }, [])

  const displayedActiveCategory = activeFilter ?? activeScrollCategory

  return (
    <div className="relative min-h-screen bg-background">
      {/* Decorative background */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-40 right-1/4 size-80 rounded-full bg-mint/15 blur-3xl" />
        <div className="absolute top-1/3 -left-20 size-60 rounded-full bg-blue/15 blur-3xl" />
        <div className="absolute bottom-1/4 right-1/3 size-72 rounded-full bg-rose/10 blur-3xl" />
        <div className="absolute -bottom-20 left-1/4 size-56 rounded-full bg-amber/15 blur-3xl" />
      </div>

      <div className="relative z-10">
        <DashboardHeader
          activeRegion={activeRegion}
          onRegionChange={setActiveRegion}
        />

        <ControlBar
          categories={categories}
          activeFilter={activeFilter}
          onFilterChange={handleFilterChange}
        />

        <BookmarkTabs
          categories={categories}
          activeCategory={displayedActiveCategory}
          onCategoryClick={handleBookmarkClick}
        />

        <main className="px-6 py-8 pl-14">
          {/* Summary cards */}
          <div className="mx-auto mb-8 grid max-w-7xl grid-cols-4 gap-4">
            {categories.map((cat) => {
              const section = sections.find((s) => s.category === cat.id)
              // Compute total achievement across all quarters
              const totalAchievement = section
                ? section.quarters.reduce((s, q) => s + q.total.achievement, 0)
                : 0
              const totalTarget = section
                ? section.quarters.reduce((s, q) => s + q.total.target, 0)
                : 0
              const overallRate = totalTarget > 0
                ? Math.round((totalAchievement / totalTarget) * 1000) / 10
                : 0

              return (
                <button
                  key={cat.id}
                  onClick={() => handleFilterChange(cat.id)}
                  className={`group rounded-xl border border-glass-border p-4 text-left backdrop-blur-md transition-all hover:shadow-lg ${
                    activeFilter === cat.id
                      ? `${cat.lightColor} border-2 ${cat.borderColor} shadow-lg`
                      : "bg-glass hover:bg-card"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`inline-block size-2 rounded-full ${cat.color}`} />
                    <span className="text-xs font-medium text-muted-foreground">
                      {cat.label}
                    </span>
                  </div>
                  <p className={`mt-2 font-mono text-2xl font-bold tabular-nums ${cat.fgColor}`}>
                    {formatNumber(totalAchievement)}
                  </p>
                  <div className="mt-1 flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      Target: {formatNumber(totalTarget)}
                    </span>
                    <span className={`font-mono text-xs font-semibold ${cat.fgColor}`}>
                      {overallRate}%
                    </span>
                  </div>
                </button>
              )
            })}
          </div>

          {/* Main KPI Table */}
          <KPITable
            sections={sections}
            activeFilter={activeFilter}
            sectionRefs={sectionRefs}
          />

          <div className="mt-6 text-center text-xs text-muted-foreground">
            {"Region: "}
            <span className="font-medium text-foreground">
              {activeRegion === "summary" ? "All Regions" : activeRegion.toUpperCase()}
            </span>
            {" \u00B7 Data refreshed daily"}
          </div>
        </main>
      </div>
    </div>
  )
}
