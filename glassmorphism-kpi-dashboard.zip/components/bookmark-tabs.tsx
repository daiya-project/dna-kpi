"use client"

import { motion } from "framer-motion"
import { cn } from "@/lib/utils"
import { type CategoryConfig } from "@/lib/dashboard-data"
import { Bookmark, BarChart3, Megaphone, Receipt } from "lucide-react"

const categoryIcons: Record<string, React.ReactNode> = {
  cm: <BarChart3 className="size-4" />,
  media: <Bookmark className="size-4" />,
  ads: <Megaphone className="size-4" />,
  "media-fee": <Receipt className="size-4" />,
}

interface BookmarkTabsProps {
  categories: CategoryConfig[]
  activeCategory: string | null
  onCategoryClick: (id: string) => void
}

export function BookmarkTabs({
  categories,
  activeCategory,
  onCategoryClick,
}: BookmarkTabsProps) {
  return (
    <div className="fixed left-0 top-1/2 z-40 flex -translate-y-1/2 flex-col gap-2">
      {categories.map((cat, index) => {
        const isActive = activeCategory === cat.id
        return (
          <motion.button
            key={cat.id}
            onClick={() => onCategoryClick(cat.id)}
            initial={{ x: -60 }}
            animate={{
              x: isActive ? 0 : -8,
            }}
            whileHover={{ x: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            className={cn(
              "group flex items-center gap-2 rounded-r-lg border border-l-0 px-3 py-3 text-sm font-medium shadow-lg backdrop-blur-md transition-colors",
              isActive
                ? cn(cat.color, "border-transparent text-background")
                : "border-glass-border bg-glass text-muted-foreground hover:text-foreground"
            )}
            style={{ transitionDelay: `${index * 30}ms` }}
          >
            <span className="flex items-center gap-2">
              {categoryIcons[cat.id]}
              <span className={cn("origin-left transition-all", isActive ? "w-auto opacity-100" : "w-0 overflow-hidden opacity-0 group-hover:w-auto group-hover:opacity-100")}>
                {cat.shortLabel}
              </span>
            </span>
          </motion.button>
        )
      })}
    </div>
  )
}
