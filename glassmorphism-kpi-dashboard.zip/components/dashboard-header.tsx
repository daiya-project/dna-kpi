"use client"

import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LayoutDashboard } from "lucide-react"

interface DashboardHeaderProps {
  activeRegion: string
  onRegionChange: (region: string) => void
}

export function DashboardHeader({ activeRegion, onRegionChange }: DashboardHeaderProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-glass-border bg-glass backdrop-blur-xl">
      <div className="flex items-center justify-between px-6 py-3">
        <div className="flex items-center gap-3">
          <div className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <LayoutDashboard className="size-5" />
          </div>
          <div>
            <h1 className="text-lg font-semibold tracking-tight text-foreground">
              KPI Dashboard
            </h1>
            <p className="text-xs text-muted-foreground">
              Performance Overview
            </p>
          </div>
        </div>

        <Tabs value={activeRegion} onValueChange={onRegionChange}>
          <TabsList className="border border-glass-border bg-glass backdrop-blur-md">
            <TabsTrigger value="summary" className="text-xs font-medium">
              Summary
            </TabsTrigger>
            <TabsTrigger value="kr" className="text-xs font-medium">
              KR
            </TabsTrigger>
            <TabsTrigger value="us" className="text-xs font-medium">
              US
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
    </header>
  )
}
