"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { ChevronDown, ChevronRight } from "lucide-react"
import {
  type SectionData,
  type MonthData,
  type CategoryConfig,
  quarterlyMetricLabels,
  monthlyMetricLabels,
  getCategoryConfig,
} from "@/lib/dashboard-data"

function formatNumber(num: number): string {
  if (Math.abs(num) >= 1000) {
    return num.toLocaleString("en-US")
  }
  return num.toString()
}

function formatCell(metricLabel: string, value: number): string {
  if (metricLabel.includes("Rate") || metricLabel === "Daily M/M" || metricLabel === "Daily Q/Q") {
    return `${value}%`
  }
  return formatNumber(value)
}

function getMetricValue(data: MonthData, metricIndex: number): number {
  const keys: (keyof MonthData)[] = [
    "target",
    "dailyTarget",
    "achievement",
    "achievementRate",
    "dailyAchievement",
    "dailyAchievementRate",
    "momOrQoq",
  ]
  return data[keys[metricIndex]]
}

interface GlassProgressBarProps {
  target: number
  achievement: number
  rate: number
  config: CategoryConfig
}

function GlassProgressBar({ target, achievement, rate, config }: GlassProgressBarProps) {
  const percentage = Math.min(rate, 100)

  return (
    <motion.div
      initial={{ opacity: 0, scaleX: 0.8 }}
      animate={{ opacity: 1, scaleX: 1 }}
      exit={{ opacity: 0, scaleX: 0.8 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="relative mx-1 overflow-hidden rounded-lg border border-glass-border bg-glass/60 backdrop-blur-md"
    >
      <motion.div
        className={cn("absolute inset-y-0 left-0 bg-gradient-to-r opacity-40", config.gradient)}
        initial={{ width: 0 }}
        animate={{ width: `${percentage}%` }}
        transition={{ duration: 0.6, delay: 0.15, ease: "easeOut" }}
      />
      <div className="relative flex items-center justify-center px-3 py-2">
        <span className={cn("font-mono text-xs font-semibold tabular-nums", config.fgColor)}>
          {formatNumber(target)} / {formatNumber(achievement)} ({rate}%)
        </span>
      </div>
    </motion.div>
  )
}

interface KPITableProps {
  sections: SectionData[]
  activeFilter: string | null
  sectionRefs: React.MutableRefObject<Record<string, HTMLTableSectionElement | null>>
}

export function KPITable({ sections, activeFilter, sectionRefs }: KPITableProps) {
  // Track which quarters are collapsed: key = "category-Q1"
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({})

  const toggleQuarter = (category: string, quarter: string) => {
    const key = `${category}-${quarter}`
    setCollapsed((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  const isCollapsed = (category: string, quarter: string) =>
    collapsed[`${category}-${quarter}`] ?? false

  return (
    <div className="relative mx-auto w-full max-w-7xl overflow-hidden rounded-xl border border-glass-border bg-glass shadow-xl shadow-glass-shadow backdrop-blur-xl">
      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-sm">
          {sections.map((section) => {
            const config = getCategoryConfig(section.category)
            const isHighlighted = activeFilter === section.category
            const isDimmed = activeFilter !== null && !isHighlighted

            return (
              <motion.tbody
                key={section.category}
                ref={(el) => {
                  sectionRefs.current[section.category] = el
                }}
                id={`section-${section.category}`}
                className="scroll-mt-[120px]"
                animate={{ opacity: isDimmed ? 0.35 : 1 }}
                transition={{ duration: 0.3 }}
              >
                {/* Section header */}
                <tr className={cn("border-t-2", config.borderColor, isHighlighted && config.lightColor)}>
                  <td
                    colSpan={100}
                    className={cn("sticky left-0 px-4 py-2.5 text-xs font-bold uppercase tracking-widest", config.fgColor)}
                  >
                    <div className="flex items-center gap-2">
                      <span className={cn("inline-block size-2.5 rounded-full", config.color)} />
                      {config.label}
                    </div>
                  </td>
                </tr>

                {/* Per-quarter blocks */}
                {section.quarters.map((quarter) => {
                  const qCollapsed = isCollapsed(section.category, quarter.label)

                  return (
                    <AnimatePresence key={quarter.label} initial={false}>
                      {/* Quarter column header row */}
                      <tr className={cn("border-b border-border/50", isHighlighted && config.lightColor)}>
                        {/* Metric label column header */}
                        <td className="sticky left-0 z-10 min-w-[180px] border-r border-glass-border bg-glass px-4 py-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground backdrop-blur-xl">
                          Metric
                        </td>
                        {/* Quarter total header with toggle */}
                        <td className="min-w-[120px] border-r border-glass-border bg-secondary/40 px-2 py-2 text-center">
                          <button
                            onClick={() => toggleQuarter(section.category, quarter.label)}
                            className={cn(
                              "inline-flex items-center gap-1 rounded-md px-2 py-0.5 font-mono text-xs font-bold transition-colors hover:bg-secondary",
                              config.fgColor
                            )}
                          >
                            {qCollapsed ? (
                              <ChevronRight className="size-3.5" />
                            ) : (
                              <ChevronDown className="size-3.5" />
                            )}
                            {quarter.label} Total
                          </button>
                        </td>
                        {/* Month headers */}
                        {quarter.months.map((m) => (
                          <td
                            key={m.label}
                            className={cn(
                              "min-w-[110px] px-3 py-2 text-center font-mono text-xs font-semibold uppercase tracking-wider text-muted-foreground",
                              qCollapsed && "opacity-0"
                            )}
                          >
                            {m.label}
                          </td>
                        ))}
                      </tr>

                      {/* EXPANDED: Show quarterly + monthly metric rows */}
                      {!qCollapsed && (
                        <>
                          {/* Quarterly metrics (Group A) */}
                          {quarterlyMetricLabels.map((metricLabel, metricIdx) => (
                            <motion.tr
                              key={`q-${quarter.label}-${metricLabel}`}
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                              transition={{ duration: 0.25, delay: metricIdx * 0.02 }}
                              className={cn(
                                "border-b border-border/30 transition-colors hover:bg-secondary/30",
                                isHighlighted && config.lightColor
                              )}
                            >
                              <td className={cn(
                                "sticky left-0 z-10 border-r border-glass-border px-4 py-1.5 text-xs font-medium text-foreground backdrop-blur-sm",
                                isHighlighted && config.lightColor
                              )}>
                                {metricLabel}
                              </td>
                              {/* Quarter total value */}
                              <td className="border-r border-glass-border bg-secondary/30 px-3 py-1.5 text-right font-mono text-xs font-semibold tabular-nums text-foreground">
                                {formatCell(metricLabel, getMetricValue(quarter.total, metricIdx))}
                              </td>
                              {/* Monthly values */}
                              {quarter.months.map((m) => (
                                <td
                                  key={m.label}
                                  className="px-3 py-1.5 text-right font-mono text-xs tabular-nums text-foreground"
                                >
                                  {formatCell(metricLabel, getMetricValue(m.data, metricIdx))}
                                </td>
                              ))}
                            </motion.tr>
                          ))}

                          {/* Monthly metrics (Group B) - per month */}
                          {monthlyMetricLabels.map((metricLabel, metricIdx) => (
                            <motion.tr
                              key={`m-${quarter.label}-${metricLabel}`}
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: "auto" }}
                              exit={{ opacity: 0, height: 0 }}
                              transition={{ duration: 0.25, delay: (7 + metricIdx) * 0.02 }}
                              className={cn(
                                "border-b border-border/30 transition-colors hover:bg-secondary/30",
                                metricIdx === 0 && "border-t border-border",
                                isHighlighted && config.lightColor
                              )}
                            >
                              <td className={cn(
                                "sticky left-0 z-10 border-r border-glass-border px-4 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur-sm",
                                isHighlighted && config.lightColor
                              )}>
                                <span className="text-muted-foreground/60">{"  "}</span>
                                {metricLabel}
                              </td>
                              {/* Quarter total for monthly metric (average) */}
                              <td className="border-r border-glass-border bg-secondary/30 px-3 py-1.5 text-right font-mono text-xs tabular-nums text-muted-foreground">
                                --
                              </td>
                              {quarter.months.map((m) => (
                                <td
                                  key={m.label}
                                  className="px-3 py-1.5 text-right font-mono text-xs tabular-nums text-foreground"
                                >
                                  {formatCell(metricLabel, getMetricValue(m.data, metricIdx))}
                                </td>
                              ))}
                            </motion.tr>
                          ))}
                        </>
                      )}

                      {/* COLLAPSED: Show single summary row with progress bar */}
                      {qCollapsed && (
                        <motion.tr
                          key={`collapsed-${quarter.label}`}
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          transition={{ duration: 0.3 }}
                          className={cn(
                            "border-b border-border/50",
                            isHighlighted && config.lightColor
                          )}
                        >
                          <td className={cn(
                            "sticky left-0 z-10 border-r border-glass-border px-4 py-3 text-xs font-bold backdrop-blur-sm",
                            config.fgColor,
                            isHighlighted && config.lightColor
                          )}>
                            {quarter.label} Summary
                          </td>
                          <td className="border-r border-glass-border bg-secondary/30 px-3 py-3 text-center font-mono text-xs font-bold tabular-nums text-foreground">
                            {formatNumber(quarter.total.achievement)}
                          </td>
                          <td colSpan={3} className="py-2 pr-2">
                            <GlassProgressBar
                              target={quarter.total.target}
                              achievement={quarter.total.achievement}
                              rate={quarter.total.achievementRate}
                              config={config}
                            />
                          </td>
                        </motion.tr>
                      )}
                    </AnimatePresence>
                  )
                })}

                {/* Spacer between sections */}
                <tr>
                  <td colSpan={100} className="h-3 border-0 bg-transparent" />
                </tr>
              </motion.tbody>
            )
          })}
        </table>
      </div>
    </div>
  )
}
